/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calc;

import static java.lang.System.in;
import java.math.BigDecimal;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 *
 * @author Eleasar
 */
public class FXMLDocumentController implements Initializable {
    
    private BigDecimal linkeZahl;
    private String operator;
    private boolean zahlEingabe;
    
    @FXML
    private TextField textfeld;
    
    public FXMLDocumentController() {
        this.linkeZahl = BigDecimal.ZERO;
        this.operator = "";
        this.zahlEingabe = false;
    }
    @FXML
    public void operatorKnopf(ActionEvent evt) {
        Button knopf = (Button)evt.getSource();
        String knopfName = knopf.getText();
        
        //Überprüfen, ob Eingabe der Löschen-Knopf ist
        if ("C".equals(knopfName)){
           if ("C".equals(knopfName)) {
               linkeZahl = BigDecimal.ZERO;
           }
           operator = "";
           zahlEingabe = true;
           textfeld.clear();
        }
        //Überprüfen, ob Eingabe eine Zahl ist
        if (knopfName.matches("[0-9\\.]")) {
            if (!zahlEingabe) {
                zahlEingabe = true;
                textfeld.clear();
            }
            
            textfeld.appendText(knopfName);
        }
        
        //Überprüfen, ob Eingabe ein Operator ist
        if (knopfName.matches("[x\\+\\–\\÷]")) {
            linkeZahl = new BigDecimal(textfeld.getText());
            operator = knopfName;
            zahlEingabe = false;
            
        }
        
        if ("=".equals(knopfName)) {
            BigDecimal rechteZahl = zahlEingabe ? new BigDecimal(textfeld.getText()) : linkeZahl;
            linkeZahl = rechne(operator, linkeZahl, rechteZahl);
            textfeld.setText(linkeZahl.toString());
            zahlEingabe = false;
        }
        
        if ("= Binär".equals(knopfName)) {
            BigDecimal rechteZahl = zahlEingabe ? new BigDecimal(textfeld.getText()) : linkeZahl;
            
        }
    }
        
        public BigDecimal rechne(String operator, BigDecimal linkeZahl , BigDecimal rechteZahl) {
            switch (operator) {
                case "+": 
                    return linkeZahl.add(rechteZahl);
                case "–":
                    return linkeZahl.subtract(rechteZahl);
                case "x":
                    return linkeZahl.multiply(rechteZahl);
                case "÷":
                    return linkeZahl.divide(rechteZahl);
            }
            return null;
        }

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
